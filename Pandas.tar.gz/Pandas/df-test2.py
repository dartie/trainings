import pandas as pd

# initialize data of lists.
data1 = {'Name': ['Tom', 'Lisa', 'Krish', 'Jack'],
         'Age': [20, 21, 19, 18],
         'Gender': ["M", "F", "M", "M"]
         }

data2 = {'Name': ['Mark', 'Stefania', 'Simon', 'Ed'],
         'Age': [25, 26, 15, 38],
         'Gender': ["M", "F", "M", "M"]
         }

# Create DataFrame
df1 = pd.DataFrame(data1)
df2 = pd.DataFrame(data2)

dfc1 = pd.concat([df1, df2])
dfc2 = pd.concat([df1, df2], axis=1)

