import pandas as pd

df = pd.read_csv("https://raw.githubusercontent.com/JackyP/testing/master/datasets/nycflights.csv", usecols=range(1, 17))

newdf = df[(df.origin == "JFK") & (df.carrier == "B6")]

newdf2 = df.loc[(df.origin == "JFK") & (df.carrier == "B6")]

newdf3 = df.query('origin == "JFK" & carrier == "B6"')

newdf4 = df[~(df.origin == "JFK")]

newdf5 = df[df['dest'].str[0] == 'M']

df_search_result = df[df['dest'].str.contains("GA", na=False)]

print()