# Create a DataFrame
import pandas as pd
import numpy as np

technologies = {
    'Courses': ["Spark", "PySpark", "Hadoop", "Python"],
    'Fee': [22000, 25000, np.nan, 24000],
    'Duration': ['30day', None, '55days', np.nan],
    'Discount': [1000, 2300, 1000, np.nan]
}
df = pd.DataFrame(technologies)

# add new column url
df['url'] = df['Courses'].apply(lambda x: "http://" + x + ".com")

# add new column url https
df['url_https'] = df.apply(lambda row: "https://" + row['Courses'] + str(row['Duration']) + ".it", axis=1)

print(df)