# import plotly
# import plotly.graph_objs as go
# import pandas as pd
#
# df = pd.read_csv('https://raw.githubusercontent.com/pcm-dpc/COVID-19/master/dati-andamento-nazionale/dpc-covid19-ita-andamento-nazionale.csv')
# # Create a trace
# data = [go.Scatter(
#     x=df['data'],
#     y=df['totale_positivi'],
# )]
# layout = go.Layout(
#         xaxis=dict(
#             title='Data',
#         ),
#         yaxis=dict(
#             title='Totale positivi',
#         )
#     )
# fig = go.Figure(data=data, layout=layout)
#
# plotly.offline.plot(fig,filename='positives.html')

# import plotly
# import plotly.graph_objs as go
# labels = ['home', 'transports', 'food']
# sizes = ['500', '300', '100']
#
# # Data to plot with plotly
# trace = go.Pie(labels=labels, values=sizes)
#
# div_tag = plotly.offline.plot([trace], include_plotlyjs=False,  output_type='div')
# html_content = plotly.offline.plot([trace], include_plotlyjs=True)

# import pandas as pd
# import plotly
# import plotly.graph_objs as go
#
# df = pd.DataFrame({
#     'labels': ['home', 'transports', 'food'],
#     'sizes': ['500', '300', '100']
# })
#
#
# # Data to plot with plotly
# trace = go.Pie(labels=df["labels"], values=df["sizes"])
#
# #div_tag = plotly.offline.plot([trace], include_plotlyjs=False,  output_type='div')
# html_content = plotly.offline.plot([trace], include_plotlyjs=True, filename='test.html', auto_open=False)
# print()


# import plotly
# import plotly.graph_objs as go
# import pandas as pd
#
# df = pd.read_csv('https://raw.githubusercontent.com/pcm-dpc/COVID-19/master/dati-andamento-nazionale/dpc-covid19-ita-andamento-nazionale.csv')
#
# # Create a trace
# data = [go.Scatter(
#     x=df['data'],
#     y=df['totale_positivi'],
# )]
# layout = go.Layout(
#         xaxis=dict(
#             title='Data',
#         ),
#         yaxis=dict(
#             title='Totale positivi',
#         )
#     )
# fig = go.Figure(data=data, layout=layout)
#
# plotly.offline.plot(fig,filename='positives.html')


# import pandas as pd
# import numpy as np
# import matplotlib
# import cufflinks as cf
# import plotly
# import plotly.offline as py
# import plotly.graph_objs as go
#
# cf.go_offline() # required to use plotly offline (no account required).
# # py.init_notebook_mode() # graphs charts inline (IPython).
#
# # url = 'https://data.cityofnewyork.us/resource/qiz3-axqb.json?$limit=1000000&$where=date%20between%20%272014-01-01T00:00:00%27%20and%20%272015-01-01T00:00:00%27'
# url = 'https://data.cityofnewyork.us/resource/qiz3-axqb.json?$limit=100'
#
# # collisions = pd.read_json("file.json")
# collisions = pd.read_json(url)
#
# contributing_factors = pd.concat(
#           [collisions.contributing_factor_vehicle_1,
#            collisions.contributing_factor_vehicle_2,
#            collisions.contributing_factor_vehicle_3,
#            collisions.contributing_factor_vehicle_4,
#            collisions.contributing_factor_vehicle_5])
#
# contributing_factors.value_counts().iplot(kind='bar')


# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt
#
# # Reading in the data
# nifty_data = pd.read_csv('NIFTY_data_2020.csv',parse_dates=["Date"],index_col='Date')
# # print(nifty_data.head())
#
# nifty_data_resample = nifty_data.resample(rule = 'M').mean()
# # print(nifty_data_resample)
#
# # nifty_data.plot(title='Nifty Index values in 2020',
# #                 xlabel='Values',
# #                 figsize=(10, 6)
# #                 )
#
# # nifty_data.plot(kind='scatter',
# #         x='NIFTY FMCG index',
# #         y='NIFTY Bank index',
# #         title='Scatter Plot for NIFTY Index values in 2020',
# #         figsize=(10,6)
# #                 )
#
# nifty_data_resample.plot(kind='barh',figsize=(10,6))

# import seaborn as sns
# import matplotlib.pyplot as plt
# sns.set_theme(style="whitegrid")
#
# # Load the example diamonds dataset
# diamonds = sns.load_dataset("diamonds")
#
# # Draw a scatter plot while assigning point colors and sizes to different
# # variables in the dataset
# f, ax = plt.subplots(figsize=(6.5, 6.5))
# sns.despine(f, left=True, bottom=True)
# clarity_ranking = ["I1", "SI2", "SI1", "VS2", "VS1", "VVS2", "VVS1", "IF"]
# sns.scatterplot(x="carat", y="price",
#                 hue="clarity", size="depth",
#                 palette="ch:r=-.2,d=.3_r",
#                 hue_order=clarity_ranking,
#                 sizes=(1, 8), linewidth=0,
#                 data=diamonds, ax=ax)

# import pandas as pd
# import seaborn as sns
# import matplotlib.pyplot as plt
#
# flights = sns.load_dataset("flights")
# flights = flights.pivot("month", "year", "passengers")
# ax=sns.heatmap(flights)
# plt.show()

import seaborn as sns

tips = sns.load_dataset("tips")
iris = sns.load_dataset("iris")
titanic = sns.load_dataset("titanic")
planets = sns.load_dataset("planets")

sns.scatterplot(x="tip", y="total_bill", data=tips)
sns.histplot(tips['tip'], kde=True, bins=15)


