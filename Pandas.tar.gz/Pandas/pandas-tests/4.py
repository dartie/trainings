import pandas as pd
df = pd.read_csv("https://raw.githubusercontent.com/JackyP/testing/master/datasets/nycflights.csv", usecols=range(1,17))

newdf = df[(df.origin == "JFK") & (df.carrier == "B6")]

print(newdf)
