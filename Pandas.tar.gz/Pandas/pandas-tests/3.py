import pandas as pd

# initialize data of lists.
data = {'Name': ['Tom', 'Lisa', 'Krish', 'Jack'],
        'Age': [20, 21, 19, 18],
        'Gender': ["M", "F", "M", "M"]
        }

# Create DataFrame
df = pd.DataFrame(data)

# Group by
by_gender = df.groupby("Gender")

for group_value, group_df in by_gender:
    print(group_value)
    print(group_df)

print(df)
