# importing pandas as pd
import pandas as pd

# Creating the Series
sr = pd.Series([10, 10, 20, 40, 70])

# Print results
print(sr.mean())
print(sr.median())
