# from matplotlib import pyplot as plt
# import numpy as np
#
# # Generate 100 random data points along 3 dimensions
# x, y, scale = np.random.randn(3, 100)
# fig, ax = plt.subplots()
#
# # Map each onto a scatterplot we'll create with Matplotlib
# ax.scatter(x=x, y=y, c=scale, s=np.abs(scale)*500)
# ax.set(title="Some random data, created with JupyterLab!")
# plt.show()

# import pandas as pd
# import plotly.graph_objects as go
#
# data = [
#     ['Ravi', 21, 67],
#     ['Kiran', 24, 61],
#     ['Anita', 18, 46],
#     ['Smita', 20, 78],
#     ['Sunil', 17, 90]
# ]
#
# df = pd.DataFrame(data, columns=['name', 'age', 'marks'], dtype=float)
#
# print(df)
#
# trace = go.Bar(x=df.name, y=df.marks)
# fig = go.Figure(data=[trace])
#
# fig.show()

#
# import plotly
# import plotly.graph_objs as go
# import pandas as pd
#
# df = pd.read_csv('https://raw.githubusercontent.com/pcm-dpc/COVID-19/master/dati-andamento-nazionale/dpc-covid19-ita-andamento-nazionale.csv')
#
# # Create a trace
# data = [go.Scatter(
#     x=df['data'],
#     y=df['totale_positivi'],
# )]
# layout = go.Layout(
#         xaxis=dict(
#             title='Data',
#         ),
#         yaxis=dict(
#             title='Totale positivi',
#         )
#     )
# fig = go.Figure(data=data, layout=layout)
#
# plotly.offline.plot(fig,filename='positives.html')

import plotly
import plotly.graph_objs as go

labels = ['home', 'transports', 'food']
sizes = ['500', '300', '100']

# Data to plot with plotly
trace = go.Pie(labels=labels, values=sizes)

div_tag = plotly.offline.plot([trace], include_plotlyjs=False, output_type='div')
html_content = plotly.offline.plot([trace], include_plotlyjs=True, auto_open=False)

print()