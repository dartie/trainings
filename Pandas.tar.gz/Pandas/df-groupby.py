import pandas as pd

# initialize data of lists.
data = {'Name': ['Tom', 'Lisa', 'Krish', 'Jack'],
        'Age': [20, 21, 19, 18],
        'Gender': ["M", "F", "M", "M"]
        }

# Create DataFrame
df = pd.DataFrame(data)

# shift column 'Name' to first position
first_column = df.pop('Name')

# insert column using insert(position,column_name,
# first_column) function
df.insert(1, 'Name', first_column)

print(df)
